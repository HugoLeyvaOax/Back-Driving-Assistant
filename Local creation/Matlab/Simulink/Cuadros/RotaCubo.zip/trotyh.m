function Ry = trotyh(angulo)
Ry=[cos(angulo), 0, sin(angulo), 0;
    0, 1, 0, 0;
    -sin(angulo), 0, cos(angulo),0;
    0, 0, 0, 1];
