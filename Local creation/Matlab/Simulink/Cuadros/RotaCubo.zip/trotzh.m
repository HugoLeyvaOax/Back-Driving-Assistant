function Rz = trotzh(angulo)
Rz=[cos(angulo), -sin(angulo), 0, 0;
    sin(angulo), cos(angulo),0, 0;
    0, 0, 1, 0
    0, 0, 0, 1];