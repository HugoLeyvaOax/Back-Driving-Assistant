function Rx = trotxh(angulo)
Rx=[1, 0, 0, 0;
    0, cos(angulo),-sin(angulo), 0; 
    0, sin(angulo),cos(angulo),0;
    0, 0, 0, 1];

